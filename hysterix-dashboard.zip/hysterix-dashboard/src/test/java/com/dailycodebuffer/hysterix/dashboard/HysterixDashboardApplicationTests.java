package com.dailycodebuffer.hysterix.dashboard;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HysterixDashboardApplicationTests {

	@Test
	void contextLoads() {
	}

}
