package com.dailycodebuffer.hysterix.dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HysterixDashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(HysterixDashboardApplication.class, args);
	}

}
